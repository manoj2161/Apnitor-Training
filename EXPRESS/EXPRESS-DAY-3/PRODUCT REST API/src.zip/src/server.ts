import express from "express";
import { PORT, APP_NAME } from "./config/env.config.js";
import { productRouter } from "./routes/product.routes.js";
const app = express();
app.use(express.json());
app.use("/products", productRouter);
app.listen(PORT, () => {
  console.log(`${APP_NAME} is running at port ${PORT}`);
});
