import type { Request, Response } from "express";
import {
  getProducts,
  productById,
  createNewProduct,
  deleteProductById,
} from "../services/product.services.js";
export const getAllProducts = (req: Request, res: Response) => {
  const products = getProducts();
  const category = req.query.category;
  const search = req.query.search;
  const sort = req.query.sort;
  const order = req.query.order;
  const limitQuery = req.query.limit;
  const pageQuery = req.query.page;
  if (category) {
    const existsProduct = products.filter(
      (product) => product.category === category,
    );
    return res.status(200).json({
      success: true,
      data: existsProduct,
    });
  } else if (search) {
    const existsProduct = products.filter((product) =>
      product.name.toLowerCase().includes(search.toString().toLowerCase()),
    );
    return res.status(200).json({
      success: true,
      data: existsProduct,
    });
  } else if (sort === "price") {
    if (order === "desc") {
      const filteredProducts = [...products].sort((a, b) => b.price - a.price);
      return res.status(200).json({
        success: true,
        data: filteredProducts,
      });
    }
    const filteredProducts = [...products].sort((a, b) => a.price - b.price);
    return res.status(200).json({
      success: true,
      data: filteredProducts,
    });
  } else if (pageQuery !== undefined && limitQuery !== undefined) {
    const page = Number(pageQuery);
    const limit = Number(limitQuery);
    const skip: number = (page - 1) * limit;
    const pagedProducts = products.slice(skip, skip + limit);

    return res.status(200).json({
      success: true,
      data: pagedProducts,
    });
  }
  return res.status(200).json({
    success: true,
    data: products,
  });
};

export const getProductById = (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const existsProduct = productById(id);
  if (existsProduct) {
    return res.status(200).json({
      success: true,
      data: existsProduct,
    });
  }
  return res.status(404).json({
    success: false,
    message: "No product found",
  });
};

export const createProduct = (req: Request, res: Response) => {
  const data = req.body;
  const newProduct = createNewProduct(data);
  if (newProduct) {
    return res.status(201).json({
      success: true,
      data: newProduct,
    });
  }
  return res.status(404).json({
    success: false,
    message: "Product already exists",
  });
};

export const deleteProduct = (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const filteredProducts = deleteProductById(id);
  if (filteredProducts) {
    return res.status(200).json({
      success: true,
      data: filteredProducts,
    });
  }
  return res.status(404).json({
    success: false,
    message: "No product found",
  });
};
